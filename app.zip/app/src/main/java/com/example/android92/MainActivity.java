package com.example.android92;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
//import android.widget.Button;
//import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button[] buttons = new Button[18];
    private int[] ids = new int[]{R.id.btn_0,R.id.btn_1,R.id.btn_2,R.id.btn_3,R.id.btn_4,R.id.btn_5,R.id.btn_6,R.id.btn_7,R.id.btn_8,R.id.btn_9,R.id.btn_add,R.id.btn_clean,R.id.btn_del,R.id.btn_divide,R.id.btn_equal,R.id.btn_minus,R.id.btn_multiply,R.id.btn_point};
    TextView textView;
    boolean clear_flag;                    //清空标识
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        for(int i=0;i<ids.length;i++){
            buttons[i] = (Button)findViewById(ids[i]);      //引用xml布局文件中的按钮，固定的使用方法，对button进行实例化
            buttons[i].setOnClickListener(this);            //监听事件，没有则程序不能进行点击
        }
        textView = findViewById(R.id.textView);
    }

    public void onClick(View v) {
        String str = textView.getText().toString();//按钮点击的结果
        switch(v.getId ()){
            case R.id.btn_0:
            case R.id.btn_1:
            case R.id.btn_2:
            case R.id.btn_3:
            case R.id.btn_4:
            case R.id.btn_5:
            case R.id.btn_6:
            case R.id.btn_7:
            case R.id.btn_8:
            case R.id.btn_9:
            case R.id.btn_point:
                if(clear_flag){
                    clear_flag=false;
                    str="";
                    textView.setText ("");
                }
                textView.setText(str+((Button)v).getText ());
                break;

            case R.id.btn_add:
            case R.id.btn_minus:
            case R.id.btn_multiply:
            case R.id.btn_divide:
                if(clear_flag){
                    clear_flag=false;
                    textView.setText("");
                }
                textView.setText(str+" "+((Button)v).getText()+" ");
                break;

            case R.id.btn_del:
                if(clear_flag){
                    clear_flag=false;
                    textView.setText ("");
                }else if (str != null && !str.equals ("")){
                    textView.setText(str.substring(0,str.length()-1));    //删除一个字符
                }
                break;
            case R.id.btn_clean:
                clear_flag=false;
                str = "";
                textView.setText("");        //清空文本内容
                break;
            case R.id.btn_equal:
                getResult();              //获取结果
                break;
        }
    }

    private void getResult() {                            //算法
        String a = textView.getText().toString();
        if(a == null  || a.equals ("")){
            return;
        }
        if (!a.contains ("")){
            return;
        }
        if (clear_flag){
            clear_flag=false;
            return;
        }
        clear_flag=true;

        String str1 = a.substring(0,a.indexOf(" "));                      // 获取到运算符前面的字符
        String str_y = a.substring(a.indexOf(" ")+1,a.indexOf(" ")+2);    //获取到运算符
        String str2 = a.substring(a.indexOf(" ")+ 3);                     //获取到运算符后面的字符

        double result = 0;
        if (!str1.equals ("")  && !str2.equals ("")){
            double num1 = Double.parseDouble(str1);   //将str1、str2强制转化为double类型
            double num2 = Double.parseDouble(str2);

            if (str_y.equals ("+")){
                result = num1 + num2;
            }else if (str_y.equals ("-")){
                result = num1 - num2;
            }else if (str_y.equals ("÷")){
                if (num2 == 0){
                    result = 0;
                }else {
                    result = num1/num2;
                }
            }else if (str_y.equals ("*")){
                result = num1*num2;
            }
            if (!str1.contains (".") && !str2.contains (".") && !a.equals ("÷")){
                int k = (int) result;
                textView.setText (k+"");
            }else{
                textView.setText (result+"");
            }
        }else if (!str1.equals ("") && str2.equals ("")){
            textView.setText (a);
        }else {
            textView.setText ("");
        }
    }
}